-- Run once (deployment migration process), same as identity-admin-rbac.sql.
--
-- Required before POST /public/register-organization can succeed —
-- registrationService.js looks this role up by role_code at call time and
-- fails fast (500 TENANT_ADMIN_ROLE_MISSING) if it isn't seeded.
--
-- Permissions here only cover this service's own identity-admin resource.
-- organization-admin-service has its own separate authorization model
-- (not part of this repo) — add whatever permission rows/role mapping it
-- expects for a tenant admin there separately, in that service's own
-- seed data.

INSERT INTO roles (
  role_uuid, role_code, role_name, description, role_type, status, created_on, modified_on
)
SELECT UUID(), 'TENANT_ADMIN', 'Tenant Administrator',
       'Full administrative access within a single tenant, granted automatically to the user who self-registers a new organization',
       'TENANT', 'ACTIVE', NOW(), NOW()
WHERE NOT EXISTS (
  SELECT 1 FROM roles WHERE role_code = 'TENANT_ADMIN'
);

INSERT INTO role_permissions (role_id, permission_id, status, created_on, modified_on)
SELECT roles.role_id, permissions.permission_id, 'ACTIVE', NOW(), NOW()
FROM roles
JOIN permissions ON permissions.permission_code IN ('identity-admin:read', 'identity-admin:write')
LEFT JOIN role_permissions
  ON role_permissions.role_id = roles.role_id
  AND role_permissions.permission_id = permissions.permission_id
  AND role_permissions.status = 'ACTIVE'
WHERE roles.role_code = 'TENANT_ADMIN'
  AND role_permissions.role_permission_id IS NULL;
